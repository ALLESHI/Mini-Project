package com.Prova5;

public class Main {
    public static void main(String[] args){
        MethodsImplementation methods = new MethodsImplementation();

        methods.printNoOfTour();
        methods.printMethod();
    }
}